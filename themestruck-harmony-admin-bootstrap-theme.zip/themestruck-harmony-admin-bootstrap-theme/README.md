# [Harmony - Free responsive Bootstrap admin template ](http://themestruck.com/) by [ThemeStruck](http://themestruck.com/theme/harmony-admin)

[Harmony - Free responsive Bootstrap admin template ](http://themestruck.com/theme/harmony-admin) is a Responsive Admin Template, Dashboard template, or webapp UI starter theme. [Bootstrap](http://getbootstrap.com/)

[Harmony - Free responsive Bootstrap admin template ](http://themestruck.com/theme/harmony-admin) Beautifully Designed Responsive Bootstrap Template

## Getting Started

You can simply download or Fork this repository on Github to get started.

## Bugs and Issues

If you have any bug or Issues with this template, please comment on the [Harmony Admin Page](http://themestruck.com/theme/harmony-admin)

## Creator

ThemeStruck is sister platform of Thecodeblock and is created and maintained by **Nikhil Arora** [Reach Here](http://nikhilaroar.in), Front end designer at [Thecodeblock](http://thecodeblock.com).

* Nikhil's Twitter : [https://twitter.com/nikhilarora_in](https://twitter.com/nikhilarora_in)
* ThemeStruck's Twitter : [https://twitter.com/themestruck](https://twitter.com/themestruck)

## License

The code of this template is released under Creative commons Attribution 3.0 License. You can learn more about it on our **[Terms & License](http://themestruck.com/terms-license/)** page.